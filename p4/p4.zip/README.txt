
Pactica realizada por Antonio José Camarero Ortega


Comando para la ejecución del servidor :
 
    $   node servidor.js
    
    
Para la ejecución de los clientes:

    Cliente : http://localhost:8080/
    
    Sensores : http://localhost:8080/sensores.html
    
    Agente : http://localhost:8080/agente.html
    
Recordar que para el funcionamiento de alertas es necesario que el Agente esté abierto en el navegador.

Con sensores.html se introducen valores de temperatura e iluminación.

Los valores maximo y minimo de temperatura e iluminación son:

        temp_maxima = 25;
        luz_maxima = 30;
        
        temp_minima = 5;
        luz_minima = 0;

Si el sensor detecta valores por encima o por debajo de los limites saltan alertas.
    
